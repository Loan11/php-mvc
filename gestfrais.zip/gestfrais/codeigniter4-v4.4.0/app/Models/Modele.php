<?php
//acces au Modele parent pour l heritage
namespace App\Models;
use CodeIgniter\Model;

//=========================================================================================
//définition d'une classe Modele (meme nom que votre fichier Modele.php) 
//héritée de Modele et permettant d'utiliser les raccoucis et fonctions de CodeIgniter
//  Attention vos Fichiers et Classes Controleur et Modele doit commencer par une Majuscule 
//  et suivre par des minuscules
//=========================================================================================
class Modele extends Model {

//-------------------------------------
    //Connexionbdd file
//-------------------------------------

/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------

LOGIN---


*/
 

public function getUtilisateur($login,$mdp) { 


	$db = db_connect();


    $sql = 'SELECT * FROM visiteur WHERE login = ? AND mdp = ?';
	
//=============================
// execution de la requete sql
//=============================	
    $resultat = $db->query($sql,[$login,$mdp]);

//=============================
// récupération des données de la requete sql
//=============================
	$resultat = $resultat->getResult();

//=============================
// renvoi du résultat au Controleur
//=============================	
    return $resultat;
   
}

 
 /*-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


FICHES FORFAIT----

*/
 

public function getQtite($QTT,$idfraitforfait,$idVisiteur,$mois) {

     

//========================================================================================== 

// Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

//========================================================================================== 

    $db = db_connect();  

     
//===================================== 

// rédaction de la requete sql préparée 

//=====================================

$sql = 'UPDATE `fraisforfait` SET `quantite`=? WHERE `fraisforfait`=? AND  `id`=? AND `libelle`=?';
	
     
//===================================================== 

// execution de la requete sql en passant un parametre id 

//=====================================================  

 $resultat = $db->query($sql,[$QTT,$idfraitforfait,$idVisiteur,$mois]);

//============================= 

// récupération des données de la requete sql 

//============================= 

    //$resultat = $resultat->getResult(); 

//============================= 

// renvoi du résultat au Controleur 

//=============================      

    return $resultat; 

   

} 

//=====================================================================================================================================================================================


public function ficheNN($idVisiteur,$mois) { 


	$db = db_connect();


    $sql = 'SELECT * FROM lignefraisforfait WHERE idVisiteur = ? AND mois = ?';
	
//=============================
// execution de la requete sql
//=============================	
$resultat = $db->query($sql, [$idVisiteur, $mois]); 

$resultat = $resultat->getResult(); 



return $resultat; 

   
}






public function getMois($login) { 


	$db = db_connect();


    $sql = 'SELECT mois FROM fichefrais  WHERE idvisiteur = ?';
	
//=============================
// execution de la requete sql
//=============================	
    $resultat = $db->query($sql,[$login]);

//=============================
// récupération des données de la requete sql
//=============================
	$resultat = $resultat->getResult();

//=============================
// renvoi du résultat au Controleur
//=============================	
    return $resultat;
   
}
 
 
public function creationFiche($idVisiteur,$mois,$idfraitforfait,$QTT) {
	
   
    //==========================================================================================
    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php
    //==========================================================================================
        $db = db_connect();	
        
    //=====================================
    // rédaction de la requete sql préparée
    //=====================================
        $sql = 'INSERT INTO `lignefraisforfait` (`idVisiteur`,`mois`,`idFraisForfait`,`quantite`)
        VALUES (?, ?, ?, ?)';
        
        
    //=====================================================
    // execution de la requete sql en passant un parametre id
    //=====================================================	
        $resultat = $db->query($sql,[$idVisiteur,$mois,$idfraitforfait,$QTT]);
    //=============================
    // récupération des données de la requete sql
    //=============================
      //  $resultat = $resultat->getResult();
    
    //=============================
    // renvoi du résultat au Controleur
    //=============================		
        return $resultat;
      
    }

//-------------------------------------------------------
//          traitement form file
//-------------------------------------------------------

public function getFicheETP($idVisiteur,$mois,$idfraitforfait,$QTT) {
	
   
    //==========================================================================================
    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php
    //==========================================================================================
        $db = db_connect();	
        
    //=====================================
    // rédaction de la requete sql préparée
    //=====================================
        $sql = 'UPDATE `lignefraisforfait` SET  `quantite`=?   WHERE `idFraisForfait`=? AND  `idVisiteur`=? AND `mois`=?';
        
    //=====================================================
    // execution de la requete sql en passant un parametre id
    //=====================================================	
        $resultat = $db->query($sql,[$QTT,$idfraitforfait,$idVisiteur,$mois]);
        
    //=============================
    // récupération des données de la requete sql
    //=============================
      //  $resultat = $resultat->getResult();
    
    //=============================
    // renvoi du résultat au Controleur
    //=============================		
        return $resultat;
      
    }

//===========================================================================================================================================================================================

public function selectFicheFrais($idVisiteur,$mois) { 


	$db = db_connect();


    $sql = 'SELECT * FROM fichefrais WHERE idVisiteur = ? AND mois = ?';
	
//=============================
// execution de la requete sql
//=============================	
    $resultat = $db->query($sql,[$idVisiteur,$mois]);

//=============================
// récupération des données de la requete sql
//=============================
	$resultat = $resultat->getResult();

//=============================
// renvoi du résultat au Controleur
//=============================	
    return $resultat;
   
}


public function getFichefrais($idVisiteur,$mois,$dateModif) {
	
    //==========================================================================================
    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php
    //==========================================================================================
        $db = db_connect();	
        
    //=====================================
    // rédaction de la requete sql préparée
    //=====================================
        $sql = "INSERT INTO `fichefrais` (`idVisiteur`, `mois`, `nbJustificatifs`, `montantValide`, `dateModif`, `idEtat`) VALUES (?, ?, 0, 0, ?, 'CR')";
        
    //=====================================================
    // execution de la requete sql en passant un parametre id
    //=====================================================	
        $resultat = $db->query($sql,[$idVisiteur,$mois,$dateModif]);
        
    //=============================
    // récupération des données de la requete sql
    //=============================
        
    
    //=============================
    // renvoi du résultat au Controleur
    //=============================		
    return $resultat;
    
    
    }

      










//=====================================================================================================================================================================================
 
//=====================================================================================================================================================================================
// fonction récupérer fiche forfait

public function getFiche($idvistiteur,$mois,$idfraitforfait,$QTT) { 

     

    //========================================================================================== 

    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

    //========================================================================================== 

        $db = db_connect();  

         

    //===================================== 

    // rédaction de la requete sql préparée 

    //===================================== 

        $sql = 'UPDATE `lignefraisforfait` SET `idVisiteur`=?,`mois`=?,`idFraisForfait`=?, `quantite`=?'; 

         

    //===================================================== 

    // execution de la requete sql en passant un parametre id 

    //=====================================================  

        $resultat = $db->query($sql,[$idvistiteur,$mois,$idfraitforfait,$QTT]); 

         

    //============================= 

    // récupération des données de la requete sql 

    //============================= 

        $resultat = $resultat->getResult(); 

     

    //============================= 

    // renvoi du résultat au Controleur 

    //=============================      

        return $resultat; 

       

    } 

 
 
 

    public function getAffichagefiche($idvistiteur,$mois) { 

     

        //========================================================================================== 

        // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

        //========================================================================================== 

            $db = db_connect();  

             

        //===================================== 

        // rédaction de la requete sql préparée 

        //===================================== 

            $sql = 'SELECT * FROM fichefrais WHERE idVisiteur = ? AND mois = ?'; 

             

        //===================================================== 

        // execution de la requete sql en passant un parametre id 

        //=====================================================  

            $resultat = $db->query($sql,[]); 

             

        //============================= 

        // récupération des données de la requete sql 

        //============================= 

            $resultat = $resultat->getResult(); 

         

        //============================= 

        // renvoi du résultat au Controleur 

        //=============================      

            return $resultat; 

           

        } 

 
 
 
 

        public function getAffichage($idvistiteur,$mois,$nbjustificatif,$montantvalide,$dateModif,$idEtat) { 

     

            //========================================================================================== 

            // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

            //========================================================================================== 

                $db = db_connect();  

                 

            //===================================== 

            // rédaction de la requete sql préparée 

            //===================================== 

                $sql = "INSERT INTO `fichefrais` (`idVisiteur`, `mois`, `nbJustificatifs`, `montantValide`, `dateModif`, `idEtat`) VALUES (?, ?, ?, ?, ?, ?)"; 

                 

            //===================================================== 

            // execution de la requete sql en passant un parametre id 

            //=====================================================  

                $resultat = $db->query($sql,[]); 

                 

            //============================= 

            // récupération des données de la requete sql 

            //============================= 

                $resultat = $resultat->getResult(); 

             

            //============================= 

            // renvoi du résultat au Controleur 

            //=============================      

            return $resultat; 

             

             

            } 

 
 

         

            public function getFicheF($idVisiteur, $mois) { 

                $db = db_connect(); 

         

                $sql = 'SELECT * FROM FicheFrais WHERE idVisiteur = ? AND mois = ?'; 

                 

                $resultat = $db->query($sql, [$idVisiteur, $mois]); 

                $resultat = $resultat->getResult(); 

         

                return $resultat; 

            } 


 //fin récupérer fiche frais 
 //=========================================================================================================================================================================================
 






 // FRAIT HORS FORFAIT



 public function ficheHF($idVisiteur,$mois) { 


    $db = db_connect();


    $sql = 'SELECT * FROM lignefraishorsforfait WHERE idVisiteur = ? AND mois = ?';
    
//=============================
// execution de la requete sql
//=============================	
    $resultat = $db->query($sql,[$idVisiteur,$mois]);

//=============================
// récupération des données de la requete sql
//=============================
    $resultat = $resultat->getResult();

//=============================
// renvoi du résultat au Controleur
//=============================	
    return $resultat;
   
}


public function creationFicheHF($montant,$idVisiteur,$mois,$libelle,$date) {
        
       
    //==========================================================================================
    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php
    //==========================================================================================
        $db = db_connect();	
        
    //=====================================
    // rédaction de la requete sql préparée
    //=====================================
        $sql = 'INSERT INTO `lignefraishorsforfait` (`idVisiteur`,`mois`,`libelle`,`date`,`montant`)
        VALUES ( ?, ?, ?, ?, ?)';
        
        
    //=====================================================
    // execution de la requete sql en passant un parametre id
    //=====================================================	
        $resultat = $db->query($sql,[$montant,$idVisiteur,$mois,$libelle,$date]);
    //=============================
    // récupération des données de la requete sql
    //=============================
      //  $resultat = $resultat->getResult();
    
    //=============================
    // renvoi du résultat au Controleur
    //=============================		
        return $resultat;
      
    }

//-------------------------------------------------------
//          traitement form file
//-------------------------------------------------------

public function getFicheHF($montant,$idVisiteur,$mois,$libelle,$date) {
        
       
    //==========================================================================================
    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php
    //==========================================================================================
        $db = db_connect();	
        
    //=====================================
    // rédaction de la requete sql préparée
    //=====================================
        $sql = 'UPDATE lignefraishorsforfait SET  montant=?  WHERE libelle=? AND  idVisiteur=? AND mois=?';
        
    //=====================================================
    // execution de la requete sql en passant un parametre id
    //=====================================================	
        $resultat = $db->query($sql,[$montant,$libelle,$idVisiteur,$mois]);
        
    //=============================
    // récupération des données de la requete sql
    //=============================
      //  $resultat = $resultat->getResult();
    
    //=============================
    // renvoi du résultat au Controleur
    //=============================		
        return $resultat;
      
    }

//----------------------------------------------------------------------------------------------------------------------------------------------------------------

 //================================================================================================================================================================================================

 //début récuperer fiche hors-forfait
 
 public function getFicheHorsForfait($id,$idVisiteur,$mois,$libelle,$date,$montant) { 

     

    //========================================================================================== 

    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

    //========================================================================================== 

        $db = db_connect();  

         

    //===================================== 

    // rédaction de la requete sql préparée 

    //===================================== 

        $sql = 'UPDATE `lignefraishorsforfait` SET `id`=?,`idVisiteur`=?,`mois`=?, `libelle`=?, `date`=?, `montant`=?'; 

         

    //===================================================== 

    // execution de la requete sql en passant un parametre id 

    //=====================================================  

        $resultat = $db->query($sql,[$id,$idVisiteur,$mois,$libelle, $date, $montant]); 

         

    //============================= 

    // récupération des données de la requete sql 

    //============================= 

        $resultat = $resultat->getResult(); 

     

    //============================= 

    // renvoi du résultat au Controleur 

    //=============================      

        return $resultat; 

       

    } 







    public function getAffichageficheHF2($idvistiteur,$mois) { 

     

        //========================================================================================== 

        // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

        //========================================================================================== 

            $db = db_connect();  

             

        //===================================== 

        // rédaction de la requete sql préparée 

        //===================================== 

            $sql = 'SELECT * FROM lignefraishorsforfait WHERE idVisiteur = ? AND mois = ?'; 

             

        //===================================================== 

        // execution de la requete sql en passant un parametre id 

        //=====================================================  

            $resultat = $db->query($sql,[]); 

             

        //============================= 

        // récupération des données de la requete sql 

        //============================= 

            $resultat = $resultat->getResult(); 

         

        //============================= 

        // renvoi du résultat au Controleur 

        //=============================      

            return $resultat; 

           

        } 




            public function getFicheHF2($idVisiteur, $mois) { 

                $db = db_connect(); 

         

                $sql = 'SELECT * FROM lignefraishorsforfait WHERE idVisiteur = ? AND mois = ?'; 

                 

                $resultat = $db->query($sql, [$idVisiteur, $mois]); 

                $resultat = $resultat->getResult(); 

         

                return $resultat; 

            } 
 


//fin récupérer fiche hf
//=======================================================================================================================================================================================

//début frais forfait

public function getFraisForfait($idVisiteur,$mois,$id,$libelle,$montant) { 

     

    //========================================================================================== 

    // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

    //========================================================================================== 

        $db = db_connect();  

         

    //===================================== 

    // rédaction de la requete sql préparée 

    //===================================== 

        $sql = 'UPDATE `fraisforfait` SET `idVisiteur`=?,`mois`=?,`id`=?, `libelle`=?, `montant`=?';

         

    //===================================================== 

    // execution de la requete sql en passant un parametre id 

    //=====================================================  

        $resultat = $db->query($sql,[$idVisiteur,$mois,$id,$libelle,$montant]); 

         

    //============================= 

    // récupération des données de la requete sql 

    //============================= 

        $resultat = $resultat->getResult(); 

     

    //============================= 

    // renvoi du résultat au Controleur 

    //=============================      

        return $resultat; 

       

    } 







    public function getAffichagefraisForfait($idvistiteur,$mois) { 

     

        //========================================================================================== 

        // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

        //========================================================================================== 

            $db = db_connect();  

             

        //===================================== 

        // rédaction de la requete sql préparée 

        //===================================== 

            $sql = 'SELECT * FROM fraisforfait WHERE idVisiteur = ? AND mois = ?'; 

             

        //===================================================== 

        // execution de la requete sql en passant un parametre id 

        //=====================================================  

            $resultat = $db->query($sql,[]); 

             

        //============================= 

        // récupération des données de la requete sql 

        //============================= 

            $resultat = $resultat->getResult(); 

         

        //============================= 

        // renvoi du résultat au Controleur 

        //=============================      

            return $resultat; 

           

        } 








        public function getAffichageFF($idVisiteur,$mois,$id,$libelle,$montant) { 

     

            //========================================================================================== 

            // Connexion à la BDD en utilisant les données féninies dans le fichier app/Config/Database.php 

            //========================================================================================== 

                $db = db_connect();  

                 

            //===================================== 

            // rédaction de la requete sql préparée 

            //===================================== 

                $sql = "INSERT INTO `fichefrais` (`idVisiteur`, `mois`, `id`, `libelle`, `montant`) VALUES (?, ?, ?, ?, ?)"; 

                 

            //===================================================== 

            // execution de la requete sql en passant un parametre id 

            //=====================================================  

                $resultat = $db->query($sql,[]); 

                 

            //============================= 

            // récupération des données de la requete sql 

            //============================= 

                $resultat = $resultat->getResult(); 

             

            //============================= 

            // renvoi du résultat au Controleur 

            //=============================      

            return $resultat; 

             

             

            } 







            public function getFicheFF($idVisiteur, $mois) { 

                $db = db_connect(); 

         

                $sql = 'SELECT * FROM lignefraisforfait WHERE idVisiteur = ? AND mois = ?'; 

                 

                $resultat = $db->query($sql, [$idVisiteur, $mois]); 

                $resultat = $resultat->getResult(); 

         

                return $resultat; 

            } 





}

 
