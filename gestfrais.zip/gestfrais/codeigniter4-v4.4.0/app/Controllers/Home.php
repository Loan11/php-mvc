<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }
}



<?php
session_start();

if(isset($_GET['deconnexion']))
{ 
   if($_GET['deconnexion']==true)
{ 
session_unset();
header("location:acceuil.php");
}
}
else if($_SESSION['prenom'] !== "")
{
$user = $_SESSION['prenom'];
if($_SESSION['prenom'] !== ""){
$user = $_SESSION['prenom'];
// afficher un message
echo "<h1>Bonjour $user, vous êtes connecté</h1>";
}
}
?>


<?php
session_start();

if(isset($_GET['deconnexion']))
{ 
   if($_GET['deconnexion']==true)
{ 
session_unset();
header("location:acceuil.php");
}
}
else if($_SESSION['prenom'] !== "")
{
$user = $_SESSION['prenom'];
if($_SESSION['prenom'] !== ""){
$user = $_SESSION['prenom'];
// afficher un message
echo "<h1>Bonjour $user, vous êtes connecté</h1>";
}
}



session_start();

if(isset($_GET['deconnexion']))
{ 
   if($_GET['deconnexion']==true)
{ 
session_unset();
header("location:acceuil.php");
}
}
else if($_SESSION['prenom'] !== "")
{
$user = $_SESSION['prenom'];
if($_SESSION['prenom'] !== ""){
$user = $_SESSION['prenom'];
// afficher un message
echo "<h1>Bonjour $user, vous êtes connecté</h1>";
}
}
?>

<?php
session_start(); // Démarrez la session si ce n'est pas déjà fait

// Déconnectez l'utilisateur en supprimant toutes les données de session
session_unset();
session_destroy();

// Redirigez l'utilisateur vers une page de connexion ou une autre page appropriée
header('Location: login.php'); // Remplacez "login.php" par l'URL de votre page de connexion
exit();
?>


