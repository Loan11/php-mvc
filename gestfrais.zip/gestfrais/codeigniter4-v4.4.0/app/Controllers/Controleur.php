<?php
//acces au controller parent pour l heritage
namespace App\Controllers;
use CodeIgniter\Controller;

//=========================================================================================
//définition d'une classe Controleur (meme nom que votre fichier Controleur.php) 
//héritée de Controller et permettant d'utiliser les raccoucis et fonctions de CodeIgniter
//  Attention vos Fichiers et Classes Controleur et Modele doit commencer par une Majuscule 
//  et suivre par des minuscules
//=========================================================================================

class Controleur extends BaseController {

//=====================================================================
//Fonction index correspondant au Controleur frontal (ou index.php) en MVC libre
//=====================================================================

public function index(){ 

 
    session_start();

	
	$modele = new \App\Models\Modele();
	if(isset($_POST['login'])&&isset($_POST['mdp'])) {
		
		$this->testlogin($_POST['login'],$_POST['mdp']);
		$this->créerFiche();
	}
	elseif(isset($_POST["moisHF"])){
		$this->afficherFicheFrais($_POST["moisHF"]);
	}
	elseif(isset($_GET["action"])){
		if($_GET["action"]=="button1"){
			$this->accueil();
		}
		if($_GET["action"]=="button2"){
			$this->saisi();
		}
		if($_GET["action"]=="button3"){
			$this->consulter();
		}
		if($_GET["action"]=="button4"){
			$this->login();
		}
    if($_GET["action"]=="envoyerff"){
			$this->envoyerff();
		}
   if($_GET["action"]=="envoyerhf"){
			$this->envoyerhf();
		}
		

	}
	
	else {
		$this->login();
	}

}
		
	
	public function créerFiche() {
	$modele = new \App\Models\Modele();
	$mois=Date('m');
	$dateModif=date("m.d.y");
	$idVisiteur=$_SESSION['idvisiteur'];
	
	if(!$modele->selectFicheFrais($idVisiteur,$mois,$dateModif)){		
		$modele->getFichefrais($idVisiteur,$mois,$dateModif);
	}
	}


					
	

		public function envoyerff(){

			

				$modele = new \App\Models\Modele();
				$mois=Date('m');
				if(!session_id()){
					session_start();}
				
				$idVisiteur=$_SESSION['idvisiteur'];
			
			
		
		
		
					if(!$modele->ficheNN($idVisiteur, $mois)){
		
		
						$modele->creationFiche($idVisiteur, $mois,'ETP',0);
		
						$modele->creationFiche($idVisiteur, $mois,'KM',0);
		
						$modele->creationFiche($idVisiteur, $mois,'NUI',0);
		
						$modele->creationFiche($idVisiteur, $mois,'REP',0);
						//print_r($modele );
					}
			
					
					
					
					$ETP = $this->request->getPost('etape');
					$KM = $this->request->getPost('kilometre');
					$NUI = $this->request->getPost('nuit');
					$REP = $this->request->getPost('repas');
		
					
						
						
						$resultat = $modele->getFicheETP($idVisiteur, $mois, 'ETP', $ETP);
						
							
								$resultat = $modele->getFicheETP($idVisiteur, $mois, 'KM', $KM);
								
								
								$resultat = $modele->getFicheETP($idVisiteur, $mois, 'NUI', $NUI);
								
								
								$resultat = $modele->getFicheETP($idVisiteur, $mois, 'REP', $REP);
								
								echo view ('saisie');
								
							}
		
				
				
			public function envoyerhf() {

			
				if(isset($_POST['envoyerhf'])){
					if(!session_id()){
						session_start();}
					$idVisiteur=$_SESSION['idvisiteur'];
					$modele = new \App\Models\Modele();
					$mois=Date('m');
				
					
				
					$libelle = $this->request->getPost('libelle');
					$montant = $this->request->getPost('montant');
					$date = $this->request->getPost('date');
					
					
				
				
					$modele->creationFicheHF($idVisiteur, $mois,$libelle,$date,$montant);
				
						
						
				
					
				
					echo view('saisie');
			}
		}
//=======================================================================================================================================================================================


public function accueil() {

	echo view('accueil');
	
}

public function login() {

    echo view('login');
    
}

public function saisi() {


	echo view('saisie');
	
}

public function consulter() {

   if(!session_id()){
		session_start();}
   $login = $_SESSION["idvisiteur"];
   $Modele = new \App\Models\Modele();
   $donnees = $Modele->getMois($login);
   $data['listeMois']=$donnees[0];
   echo view('consulter',$data);
   
	
}

 
// Action 2 : Affiche les détails sur un billet 

public function testlogin($login,$mdp) {
	
	if(!session_id()){
		session_start();}

    $Modele = new \App\Models\Modele();
    
    //===============================
    //Appel d'une fonction du Modele
    //===============================	
    $donnees = $Modele->getUtilisateur($login,$mdp);
    if(isset($donnees)) {
        
        
        
        $_SESSION['idvisiteur']=$donnees[0]->id;
        $data['resultat']=$donnees;
        
        echo view('accueil',$data);
    }
    else {

        $this->accueil();

        echo "erreur d'identifiants";
    }
    
    

}

         
   



 
public function fraisforfait() {
	//================
	//acces au modele
	//================
	if(!session_id()){
		session_start();
	}
	$Modele = new \App\Models\Modele();
	
	//===============================
	//Appel d'une fonction du Modele
	//===============================	
	$donnees = $Modele->getInsertfiche();

	if(isset($donnees)) {

		
		
		$_SESSION['idvisiteur']=$donnees[0]->id;

		$data['resultat']=$donnees;
		echo view('accueil',$data);
	}
	else {

		$this->accueil();

		echo "erreur d'identifiants";
	}

}




 
 
//=====================================================================================================================================================================================
// méthode pour afficher la fiche de hors-forfait 

public function afficherFicheFrais($mois) { 

    // Récupérez les données du formulaire, par exemple, le mois sélectionné 

     
	
		if(!session_id()){
			session_start();
		}
		//print_r($mois);

    	// Accès au modèle pour récupérer les données de la fiche de frais 
    	$Modele = new \App\Models\Modele(); 
    	$idVisiteur = $_SESSION["idvisiteur"]; 
		$donnees = $Modele->getMois($idVisiteur);
		$data['listeMois']=$donnees[0];
    	//print_r($idVisiteur.$mois); 
    	// $ficheFrais = $Modele->getFicheF($idVisiteur, $mois);
		$data["ficheHF"] = $Modele->getFicheHF2($idVisiteur, $mois);
		$data["ficheFF"] = $Modele->getFicheFF($idVisiteur, $mois);
		//print_r($data["ficheFF"]);
		//print_r($data["ficheHF"]);


echo view('consulter', $data); 
 // fin méthode afficher fiche frais 
 //======================================================================================================================================================================================
 
 

// Affiche une erreur 




//fin de la classe 

}
 
}
?> 
 
 
