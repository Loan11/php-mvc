<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style3.css">
    <title>Renseigner fiche frais</title>
</head>
<body>
<div class="container">
        <div class="navigation">
            <div class="logo">
                <img src="img/gsblogo.png" alt="logo">
            </div>
			<div class="buttons">
				<ul>
			<li><a href="index.php?action=button1">Accueil</a></li>
			<br>
			<li><a href="index.php?action=button2">Renseigner fiches frais</a></li>
			<br>
			<li><a href="index.php?action=button3">Consulter fiches frais</a></li>
            <br>
			<li><a href="index.php?action=button4">Déconnexion</a></li>
		  </ul>
    		</div>
        </div>
		<section class="main">
        <div class="form-container">
        <h2><u>Renseigner fiche hors frais</u></h2>
        <div class="form">
            <h2>Frais hors forfait</h2>
            <form method="post" action="index.php?action=envoyerhf">
                <label for="Libelle">Libellé : </label>
                <input type="text" name="libelle" required>
                <br>
                <label for="montant">Montant : <input type="number" name="montant" min="0" required> € </label>
                <br>
                <label for="date"> Date d'engagement : </label>
                <input type="date" name="date" required>
                <!--- <button id="add">Ajouter</button> --->
                <br>
                <br>
                <input type="submit" value="Envoyer" name="envoyerhf">
            </form>
        </div>
        <h2><u>Renseigner fiche frais</u></h2>
    
        <div class="form">
            <h2>Frais forfaitaires</h2>
            <form method="post" action="index.php?action=envoyerff">
                <br>
                <label for="etape">Forfait Etape :
                    <input type="number" name="etape" min="0" required>
                </label>
                <br>
                <label for="kilometre">Frais kilométrique : <input type="number" name="kilometre" min="0" required> km</label>
                <br>
                <label for="nuit">Nuitée hôtel :
                    <input type="number" name="nuit" min="0" required> nuit(s)
                </label>
                <br>
                <label for="repas">Repas restaurant :
                    <input type="number" name="repas" min="0" required> repas
                </label>
                <br><br>
                <input type="submit" value="Envoyer" name="envoyerff">
            </form>
        </div>
    </div>
</section>

</body>
</html>