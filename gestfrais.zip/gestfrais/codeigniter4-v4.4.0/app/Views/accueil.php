<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style2.css" />
    <title>Accueil</title>
</head>
<body>
    <div class="container">
        <div class="navigation">
            <div class="logo">
                <img src="img/gsblogo.png" alt="logo">
            </div>
	<div class="buttons">
				<ul>
			<li><a href="index.php?action=button1">Accueil</a></li>
			<br>
			<li><a href="index.php?action=button2">Renseigner fiches frais</a></li>
			<br>
			<li><a href="index.php?action=button3">Consulter fiches frais</a></li>
            <br>
			<li><a href="index.php?action=button4">Déconnexion</a></li>
		  </ul>
    		</div>
        </div>
		<div class="main">
            <div class="content">
                <h1>Bienvenue sur notre site</h1>
                <p>Ce site est conçu pour vous aider à gérer vos frais professionnels de manière efficace. Utilisez les boutons de navigation à gauche pour accéder aux différentes fonctionnalités du site.</p>
            </div>
			</br>
			<div class="medic">
               <!-- <img src="img/medica.jpg" alt="medic"> -->
            </div>
        </div>
    </div>
</body>
</html>
