<!DOCTYPE html> 
<html lang="fr"> 
<head> 
    <meta charset="UTF-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="css/style4.css"> 
    <title>Consulter fiches de frais</title> 
</head> 
<body> 
<div class="container">
        <div class="navigation">
            <div class="logo">
                <img src="img/gsblogo.png" alt="logo">
            </div>
            <div class="buttons">
		        <ul>
			<li><a id=acc href="index.php?action=button1">Accueil</a></li>
			<br>
			<li><a id=rff href="index.php?action=button2">Renseigner fiches frais</a></li>
			<br>
			<li><a id=cff href="index.php?action=button3">Consulter fiches frais</a></li>
            <br>
			<li><a href="index.php?action=button4">Déconnexion</a></li>
		  </ul>
	        </div>
        </div>

    <section class="main"> 

    

 
 

        <br> 

 
 

        

 
 


			

        <br> 

 
 

        <section class="main">
          <div class="table-container">
            <h1 class="title"><u>Consulter fiches</u></h1>
            <form method="post" action="index.php">
             <label for="moisHF" class="select-label">Sélectionnez le mois :</label> 
                <select name="moisHF" id="moisHF"> 
                 <?php foreach ($listeMois as $mois) : ?> 
                         <?php echo("<option value=".$mois.">".$mois."</option>"); ?> 
            

                        <?php endforeach; ?> 

                     
                </select> 
                <button type="submit">Valider</button> 

            </form> 
            <br /> 
                <div class="form">
                    <h2>Frais Hors Forfait</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Date d'engagement</th>
                                <th>Libellé</th>
                                <th>Date</th>
                                <th>Montant</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (isset($ficheHF)) : ?>
                                <?php foreach ($ficheHF as $fiche) : ?>
                                    <tr>
                                        <td><?php echo isset($fiche->mois) ? $fiche->mois : ''; ?></td>
                                        <td><?php echo isset($fiche->libelle) ? $fiche->libelle : ''; ?></td>
                                        <td><?php echo isset($fiche->date) ? $fiche->date : ''; ?></td>
                                        <td><?php echo isset($fiche->montant) ? $fiche->montant : ''; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="form">
                    <h2>Frais Forfait</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Mois</th>
                                <th>Libellé</th>
                                <th>Montant</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (isset($ficheFF)) : ?>
                                <?php foreach ($ficheFF as $fiche) : ?>
                                    <tr>
                                        <td><?php echo isset($fiche->mois) ? $fiche->mois : ''; ?></td>
                                        <td><?php echo isset($fiche->idFraisForfait) ? $fiche->idFraisForfait : ''; ?></td>
                                        <td><?php echo isset($fiche->quantite) ? $fiche->quantite : ''; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
               
            </div>
        </section>
    </section>

    <br />
</body>


</html> 