<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css" />
    <title>Connexion</title>
</head>
<body>
    <div class="container">
        <div class="left">
            <div class="logo">
                <img src="img/gsblogo.png" alt="logo">
            </div>
            <h2> </h2>
        </div>
        <div class="right">
            <h1>Connexion à GSB</h1>
            <form action="index.php" method="post">
                <label>Login:</label>
                <input type="text" name="login" required>
                <label>Mot de passe:</label>
                <input type="password" name="mdp" required>
                <input type="submit" value="Se connecter">
            </form>
        </div>
    </div>
</body>
</html>
