<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Controleur::index');
$routes->post('/', 'Controleur::index');
$routes->post('postdata', 'Controleur::index');
$routes->get('getdata', 'Controleur::index');
$routes->get('bouton1', 'Controleur::accueil');
$routes->get('bouton2', 'Controleur::saisi');
$routes->post('envoyerff','Controleur::envoyerff');
$routes->post('envoyerhf','Controleur::envoyerhf');
$routes->get('bouton3', 'Controleur::afficherFicheFrais');
$routes->post('bouton3', 'Controleur::afficherFicheFrais');
$routes->get('bouton4', 'Controleur::login');
 
