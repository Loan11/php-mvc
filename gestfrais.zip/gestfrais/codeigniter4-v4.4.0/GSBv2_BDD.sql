DROP DATABASE IF EXISTS GSBv2;


CREATE DATABASE GSBv2;

USE GSBv2;


-- Création de la table FraisForfait
CREATE TABLE FraisForfait (
    id VARCHAR(25),
    libelle VARCHAR(250),
    montant DECIMAL(10,2),
    PRIMARY KEY (id)
);


-- Création de la table Etat
CREATE TABLE Etat (
    id VARCHAR(25) ,
    libelle VARCHAR(255),
    PRIMARY KEY(id)
);


-- Création de la table Visiteur
CREATE TABLE visiteur (
    id VARCHAR(25) ,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    login VARCHAR(255),
    mdp VARCHAR(255),
    adresse VARCHAR(255),
    cp VARCHAR(10),
    ville VARCHAR(255),
    dateEmbauche DATE,
    PRIMARY KEY(id)
    );
    
    
    -- Création de la table FicheFrais
CREATE TABLE FicheFrais (
    idVisiteur VARCHAR(25),
    mois varchar(8),
    nbJustificatifs INT,
    montantValide INT,
    dateModif DATE,
    idEtat varchar(25),
    PRIMARY KEY (idVisiteur, mois),
    FOREIGN KEY (idEtat) REFERENCES Etat(id),
    FOREIGN KEY (idVisiteur) REFERENCES visiteur(id)
);




-- Création de la table LigneFraisForfait
CREATE TABLE LigneFraisForfait (
    idVisiteur VARCHAR(25),
    mois varchar(8),
    idFraisForfait varchar(25),
    quantite INT,
    PRIMARY KEY (idVisiteur, mois, idFraisForfait),
    FOREIGN KEY (idVisiteur) REFERENCES FicheFrais(idVisiteur),
    FOREIGN KEY (idFraisForfait) REFERENCES FraisForfait(id)
);


-- Création de la table LigneFraisHorsForfait
CREATE TABLE LigneFraisHorsForfait (
    id VARCHAR(25) ,
    idVisiteur VARCHAR(25),
    mois varchar(8),
    libelle VARCHAR(255),
    date DATE,
    montant DECIMAL(10,2),
    PRIMARY KEY (id),
    FOREIGN KEY (idVisiteur) REFERENCES FicheFrais(idVisiteur)
    
);