<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/style2.css">
    <title>Accueil</title>
</head>
<body>
	<div class="logo">
		<img src="img/gsblogo.png" alt="logo">
	</div>
    <div class="top-banner">


	</div>
	<div class="navigation">
		<ul>
			<li><a href="bouton1">Accueil</a></li>
			<br>
			<li><a href="bouton2">Renseigner fiches frais</a></li>
			<br>
			<li><a href="bouton3">Consulter fiches frais</a></li>
		  </ul>
	</div>
	

	



</body>
</html>