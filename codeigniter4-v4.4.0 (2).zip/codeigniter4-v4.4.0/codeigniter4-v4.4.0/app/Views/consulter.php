<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style4.css">
    <title>Consulter fiches de frais</title>
</head>
<body>
	<div class="logo">
		<img src="img/gsblogo.png" alt="logo">
	</div>
    <div class="top-banner">

		<h3>Consulter vos fiches de frais</h3>
	</div>
	<div class="navigation">
		<ul>
			<li><a href="bouton1">Accueil</a></li>
			<br>
			<li><a href="bouton2">Renseigner fiches frais</a></li>
			<br>
			<li><a href="bouton3">Consulter fiches frais</a></li>
		  </ul>
	</div>
	<section class="main">
		<h2> <u>Consulter fiches de frais</u> </h2>
		<form method="post" action="bouton3">
    <label for="mois">Sélectionnez le mois :</label>
    <select name="mois" id="mois">
        <option value="01">Janvier</option>
        <option value="02">Février</option>
		<option value="03">Mars</option>
		<option value="04">Avril</option>
		<option value="05">Mai</option>
		<option value="06">Juin</option>
		<option value="07">Juillet</option>
		<option value="08">Aout</option>
		<option value="09">Septembre</option>
		<option value="10">Octobre</option>
		<option value="11">Novembre</option>
		<option value="12">Decembre</option>

    </select>
    <button type="submit">Valider</button>
</form>

		<br>

		<h2>Fiche de frais pour le mois du <?php echo $ficheFrais[0]->mois; ?></h2>

<table>
    <tbody>
        <?php foreach ($ficheFrais as $fiche) : ?>
            <tr>
                <td><?php echo $fiche->mois; ?></td>
                <td><?php echo $fiche->nbJustificatifs; ?></td>
                <td><?php echo $fiche->montantValide; ?></td>
                <td><?php echo $fiche->dateModif; ?></td>
                <td><?php echo $fiche->idEtat; ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
		<br>

		<h2> <u>Consulter fiches Hors-forfait</u> </h2>
		<form method="post" action="bouton3">
    <label for="mois">Sélectionnez le mois :</label>
    <select name="mois" id="mois">
        <option value="01">Janvier</option>
        <option value="02">Février</option>
		<option value="03">Mars</option>
		<option value="04">Avril</option>
		<option value="05">Mai</option>
		<option value="06">Juin</option>
		<option value="07">Juillet</option>
		<option value="08">Aout</option>
		<option value="09">Septembre</option>
		<option value="10">Octobre</option>
		<option value="11">Novembre</option>
		<option value="12">Decembre</option>

    </select>
    <button type="submit">Valider</button>
</form>

		<h2>Frais Hors Forfait</h2>

		<table>
            <thead> <!-- En-tête du tableau -->
                <tr>
                    <th>Libellé</th>
                    <th>Montant</th>
                    <th>Date d'engagement</th>
                </tr>
			</thead>
			<tbody>
        
    </tbody>
		</table>
	</section>
</body>
</html>