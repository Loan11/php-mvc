<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style3.css">
    <title>Renseigner fiche frais</title>
</head>
<body>
	<div class="logo">
		<img src="img/gsblogo.png" alt="logo">
	</div>
    <div class="top-banner">

		<h3>Renseigner vos fiches de frais</h3>
	</div>
	<div class="navigation">
		<ul>
			<li><a href="bouton1">Accueil</a></li>
			<br>
			<li><a href="bouton2">Renseigner fiches frais</a></li>
			<br>
			<li><a href="bouton3">Consulter fiches frais</a></li>
		  </ul>
	</div>
	<section class="main">
		<h2><u>Formulaire</u></h2>
		<h2>Frais forfaitaires</h2>
        <form method="post" action="postdata">
			<br>
			<label for="etape">Forfait Etape
				<input type="number" name="etape" min="0" required>
			</label>
			<br>
			<label for="kilometre">Frais kilométrique
				<input type="number" name="kilometre" min="0" required> km
			</label>
			<br>
			<label for="nuit">Nuitée hôtel
				<input type="number" name="nuit" min="0" required> nuit(s)
			</label>
			<br>
			<label for="repas">Repas restaurant
				<input type="number" name="repas" min="0" required> repas
			</label>
			<br><br>
			<input type="submit" value="Envoyer" name="envoyerff">
			</form> 



			<br>
			<form method="post" action="postdata">
			<h2>Frais hors forfait</h2>
			<label for="Libelle">Libellé : </label>
			<select name="libelle" id="libelle" required>
				<option value="selectionnez">- Sélectionnez un frais -</option>
				<option value="kilometreHF">Frais kilométriques</option>
				<option value="nuitHF">Nuitée hôtel</option>
				<option value="repasHF">Repas restaurant</option>
			</select>
			<label for="montant">Montant : 
				<input type="number" name="montant" min="0" required> € 
			</label>
			<label for="date"> Date d'engagement : </label>
				<input type="date" name="date" required>
			<!--- <button id="add">Ajouter</button> --->
			<br>
			<br>
			<input type="submit" value="Envoyer" name="envoyerhf">


		</form> 
		<br><br>
		<h2><u>Récupitulatifs des fiches de frais (modification / validation) </u></h2><br>

		<h2>Frais Forfait</h2>
		
		<table>
            <thead> <!-- En-tête du tableau -->
                <tr>
                    <th>Mois</th>
                    <th>Forfait Etape</th>
                    <th>Frais kilométrique</th>
					<th>Nuitée hôtel</th>
                    <th>Repas restaurant</th>
                </tr>
			</thead>
			<tbody> <!--Corps du tableau -->
				<tr>
					<td>- </td>
					<td>-</td>
					<td>-</td>
					<td>-</td>
					<td>-</td>
				</tr>
			</tbody>
		</table>
		<br>
		<button>Modifier</button> 
		<button>Valider la saisie</button>
		<br>
		<br>
		<h2>Frais Hors Forfait</h2>

		<table>
            <thead> <!-- En-tête du tableau -->
                <tr>
                    <th>Libellé</th>
                    <th>Montant</th>
                    <th>Date d'engagement</th>
                </tr>
			</thead>
			<tbody> <!--Corps du tableau -->
				<tr>
					<td>-</td>
					<td>-</td>
					<td>-</td>
				</tr>
			</tbody>
		</table>
		<br>
		<button>Modifier</button> 
		<button>Valider la saisie</button>
		
	</sections>
</body>
</html>