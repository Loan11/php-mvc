<?php
//acces au controller parent pour l heritage
namespace App\Controllers;
use CodeIgniter\Controller;

//=========================================================================================
//définition d'une classe Controleur (meme nom que votre fichier Controleur.php) 
//héritée de Controller et permettant d'utiliser les raccoucis et fonctions de CodeIgniter
//  Attention vos Fichiers et Classes Controleur et Modele doit commencer par une Majuscule 
//  et suivre par des minuscules
//=========================================================================================

class Controleur extends BaseController {

//=====================================================================
//Fonction index correspondant au Controleur frontal (ou index.php) en MVC libre
//=====================================================================
public function index(){
				
	session_start();
	if(isset($_POST['login'])&&($_POST['mdp'])) {
		
		$this->testlogin($_POST['login'],$_POST['mdp']);
		
	}



//===================================================================================================================================================================================
//FORFAIT



	if(isset($_POST['repas'])){

		$modele = new \App\Models\Modele();
		$mois=Date('m');

		$idVisiteur=$_SESSION['idvisiteur'];



			if(!$modele->ficheNN($idVisiteur, $mois)){


				$modele->creationFiche($idVisiteur, $mois,'ETP',0);

				$modele->creationFiche($idVisiteur, $mois,'KM',0);

				$modele->creationFiche($idVisiteur, $mois,'NUI',0);

				$modele->creationFiche($idVisiteur, $mois,'REP',0);
				//print_r($modele );
			}
	
			
			
			
			$ETP = $this->request->getPost('etape');
			$KM = $this->request->getPost('kilometre');
			$NUI = $this->request->getPost('nuit');
			$REP = $this->request->getPost('repas');

				
				
				
				$resultat = $modele->getFicheETP($idVisiteur, $mois, 'ETP', $ETP);
				
					
						$resultat = $modele->getFicheETP($idVisiteur, $mois, 'KM', $KM);
						
						
						$resultat = $modele->getFicheETP($idVisiteur, $mois, 'NUI', $NUI);
						
						
						$resultat = $modele->getFicheETP($idVisiteur, $mois, 'REP', $REP);
						
						
						
					}


					
					
					
				 


//==============================================================================================================================================================================
// HORS FORFAIT

if(isset($_POST['envoyerhf'])){

	$modele = new \App\Models\Modele();
	$mois=Date('m');

	$idVisiteur=$_SESSION['idvisiteur'];

	$kilometreHF = $this->request->getPost('kilometreHF');
	$nuitHF = $this->request->getPost('nuitHF');
	$repasHF = $this->request->getPost('repasHF');
	$montant = $this->request->getPost('montant');
	$date = $this->request->getPost('date');

		if(!$modele->ficheHF($idVisiteur,$mois,$date)){


			$modele->creationFicheHF($idVisiteur, $mois,'Frais kilométriques',$date,0);

			$modele->creationFicheHF($idVisiteur, $mois,'>Nuitée hôtel',$date,0);

			$modele->creationFicheHF($idVisiteur, $mois,'Repas restaurant',$date,0);

			//print_r($modele );
		}

		$i=0;
			
				
			$resultat =$modele->getFicheHF($i,$idVisiteur, $mois,'Frais kilométriques',$date,$montant);
					
					
			$modele->getFicheHF($i,$idVisiteur, $mois,'>Nuitée hôtel',$date,$montant);
					
					
			$modele->getFicheHF($i,$idVisiteur, $mois,'Repas restaurant',$date,$montant);
					
				$i++;	
					
				}


				
				
				else {
					$this->accueil();
				}
			} 

//=======================================================================================================================================================================================
	

public function accueil() {
	//================
	//acces au modele

	echo view('accueil');
	
}

	
public function login() {
	    //================
		//acces au modele

		echo view('login');
		
}

public function saisi() {
	//================
	//acces au modele

	echo view('saisie');
	
}

public function consulter() {
	//================
	//acces au modele

	echo view('consulter');
	
}

// Action 2 : Affiche les détails sur un billet
public function testlogin($login,$mdp) {
		//================
		//acces au modele
		//================
		$Modele = new \App\Models\Modele();
		
		//===============================
		//Appel d'une fonction du Modele
		//===============================	
		$donnees = $Modele->getUtilisateur($login,$mdp);
	
		if(isset($donnees)) {

			
		
			$_SESSION['idvisiteur']=$donnees[0]->id;

			$data['resultat']=$donnees;
			echo view('accueil',$data);
		}
		else {

			$this->accueil();

			echo "erreur d'identifiants";
		}
		
		
  
}

// Affiche une erreur
public function erreur($msgErreur) {
  echo view('vueErreur.php', $data);
}


public function fraisforfait() {
	//================
	//acces au modele
	//================
	$Modele = new \App\Models\Modele();
	
	//===============================
	//Appel d'une fonction du Modele
	//===============================	
	$donnees = $Modele->getInsertfiche();

	if(isset($donnees)) {

		
		
		$_SESSION['idvisiteur']=$donnees[0]->id;

		$data['resultat']=$donnees;
		echo view('accueil',$data);
	}
	else {

		$this->accueil();

		echo "erreur d'identifiants";
	}
	
	//=================================================================================
	//!!! Création d'un jeu de données $data sécurisé pouvant etre passé à la vue
	//!!! on créé une variable qui récupère le résultat de la requete : $getBillets();
	//=================================================================================
	  
	//==========================================
	//on charge la vue correspondante
	//et on envoie le jeu de données $data à la vue
	//la vue aura acces a une variable $resultat
	//==========================================

}

//==========================================================================================================================================================================================

// méthode pour afficher la fiche de frais
public function afficherFicheFrais() {
    // Récupérez les données du formulaire, par exemple, le mois sélectionné
    
	if(isset ($_POST["mois"])){
		$mois = $this->request->getPost('mois');
	}
	else {
		$mois="09";
	}
    
    

    // Accès au modèle pour récupérer les données de la fiche de frais
    $Modele = new \App\Models\Modele();
	session_start();
    $idVisiteur = $_SESSION["idvisiteur"];
	//print_r($idVisiteur.$mois);
    $ficheFrais = $Modele->getFicheFrais($idVisiteur, $mois);
	//print_r($ficheFrais);
    
    $data = []; // Initialisez un tableau vide pour transmettre des données à la vue

    if (isset($ficheFrais[0])) {
        // Si des données de fiche de frais sont trouvées, les ajouter au tableau $data
       
    }
	$data = ['ficheFrais' => $ficheFrais];

    // Chargez la vue HTML en passant le tableau $data
	return view('consulter', $data);
	print_r($data);
}




//=========================================================================================================================================================================================


// méthode pour afficher la fiche hors-forfait
public function afficherFicheHF() {
    // Récupérez les données du formulaire, par exemple, le mois sélectionné
    
	if(isset ($_POST["mois"])){
		$mois = $this->request->getPost('mois');
	}
	else {
		$mois="09";
	}
    
    

    // Accès au modèle pour récupérer les données de la fiche hors-forfait
    $Modele = new \App\Models\Modele();
	session_start();
    $idVisiteur = $_SESSION["idvisiteur"];
	//print_r($idVisiteur.$mois);
    $ficheHF = $Modele->getFicheHF($idVisiteur, $mois);
	//print_r($ficheHF);
    
    $data = []; // Initialisez un tableau vide pour transmettre des données à la vue

    if (isset($ficheFrais[0])) {
        // Si des données de fiche de frais sont trouvées, les ajouter au tableau $data
       
    }
	$data = ['ficheHF' => $ficheHF];

    // Chargez la vue HTML en passant le tableau $data
	return view('consulter', $data);
	//print_r($data);
}



//==========================
//Fin du code du controleur simple
//===========================

//fin de la classe
}




?>